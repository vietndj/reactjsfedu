import React, { Component } from 'react';
 import './App.css';
import Nav from './Nav';
import NodeList from './NodeList';
import NodeForm from './NodeForm';

class App extends Component {
  render() {
    return (
      <div >
        <Nav/>
        <div className="container">
        <div className="row">
            <NodeList/>
            <NodeForm/>
        </div>
        </div>
      </div>
    );
  }
}

export default App;
