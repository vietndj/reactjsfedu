# redux-kpt
Clone it to your machine. run

npm install
webpack -w
Then open new Terminal (CMD) tab and run "node index"
